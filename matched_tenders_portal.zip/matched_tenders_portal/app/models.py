from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

# ----------------- Company Table -----------------
class Company(Base):
    __tablename__ = "company"  # Matches your existing database table

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    industry = Column(String)
    services_offered = Column(Text)
    previous_projects = Column(Text)
    technologies_used = Column(Text)
    problems_solved = Column(Text)
    target_clients = Column(Text)
    geographic_focus = Column(Text)
    contract_budget_range = Column(String)
    preferred_contract_types = Column(Text)
    key_achievements = Column(Text)
    current_challenges = Column(Text)
    link = Column(String)
    social_media = Column(String)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)

    users = relationship("User", back_populates="company")


# ----------------- User Table -----------------
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=False)

    company = relationship("Company", back_populates="users")


# ----------------- Contract Table -----------------
class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    link = Column(String, nullable=False)
    description = Column(Text)
    location = Column(String)
    deadline = Column(String)
    budget = Column(String)
    industry = Column(String)
    scraped_at = Column(DateTime)
    company_id = Column(Integer, ForeignKey("company.id"), nullable=True)


# ----------------- Contract Assessment Table -----------------
class ContractAssessment(Base):
    __tablename__ = "contract_assessments"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, nullable=False)
    company_id = Column(Integer, nullable=False)
    contract_title = Column(String, nullable=False)
    contract_link = Column(String)
    contract_description = Column(Text)
    contract_location = Column(String)
    contract_deadline = Column(String)
    contract_budget = Column(String)
    contract_industry = Column(String)
    verdict = Column(String)
    fit_score = Column(Integer)
    opportunity_type = Column(String)
    analysis_notes = Column(Text)
    evaluated_at = Column(DateTime, default=datetime.datetime.utcnow)


# ----------------- Company Scope Table -----------------
class CompanyScope(Base):
    __tablename__ = "company_scope"

    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, nullable=False, unique=True)
    in_scope = Column(Text, nullable=False)      # JSON string
    out_of_scope = Column(Text, nullable=False)  # JSON string
    extracted_at = Column(DateTime, default=datetime.datetime.utcnow)
