from sqlalchemy.orm import declarative_base

Base = declarative_base()

from .user import User
from .company import Company
from .contract_assessments import ContractAssessment
