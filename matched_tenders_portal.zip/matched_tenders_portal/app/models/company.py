from sqlalchemy import Column, Integer, String, Text, DateTime
from sqlalchemy.orm import relationship
from app.models import Base
import datetime

class Company(Base):
    __tablename__ = "company"

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    industry = Column(String)
    services_offered = Column(Text)
    previous_projects = Column(Text)
    technologies_used = Column(Text)
    problems_solved = Column(Text)
    target_clients = Column(Text)
    geographic_focus = Column(Text)
    contract_budget_range = Column(String)
    preferred_contract_types = Column(Text)
    key_achievements = Column(Text)
    current_challenges = Column(Text)
    link = Column(String)
    social_media = Column(String)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)

    users = relationship("User", back_populates="company")
