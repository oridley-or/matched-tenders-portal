from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import get_db
from app.auth_utils import get_current_company
from app.services.contract_service import get_filtered_contracts

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request,
    company = Depends(get_current_company),
    db: Session = Depends(get_db)
):
    if not company:
        return RedirectResponse(url="/login", status_code=303)

    # Extract query parameters with defaults
    min_budget = int(request.query_params.get("min_budget", 0))
    keyword = request.query_params.get("keyword", "")
    page = int(request.query_params.get("page", 1))
    hide_zero = request.query_params.get("hide_zero") == "1"

    # Fetch filtered contracts
    contracts, total = get_filtered_contracts(
        db=db,
        company_id=company.id,
        min_budget=min_budget,
        keyword=keyword,
        page=page,
        page_size=10,
        hide_zero=hide_zero
    )

    total_pages = max((total + 9) // 10, 1)

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "company_name": company.company_name,
        "contracts": contracts,
        "min_budget": min_budget,
        "keyword": keyword,
        "page": page,
        "total_pages": total_pages,
        "total": total,
        "hide_zero": hide_zero
    })
